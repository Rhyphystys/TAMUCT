function last_mod_date()
{
	document.getElementById("last_date_mod").innerHTML ="This page was last modified on :" +
document.lastModified;
}

function yoga_alert()
{
	alert("Yin Yoga classes start next month");
}